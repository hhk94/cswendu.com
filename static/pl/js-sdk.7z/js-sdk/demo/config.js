module.exports = {
    'ACCESS_KEY': 'pJ-fVHRCcemA4fysn8RHvEO_QLv0G_uYul6GlKzx',  // 此处填写自己申请的 ACCESS_KEY
    'SECRET_KEY': 'hks1wDVonphLhPfcmfpVY96ugaEjvoxUOXwqDDVW',  // 此处填写自己申请的 SECRET_KEY
    'Bucket_Name': 'wangeditor', // 此处填写自己的 Bucket_Name
    'Port': 19110,
    'Uptoken_Url': 'uptoken',
    'Domain': 'http://qiniu-plupload.qiniudn.com/'
};